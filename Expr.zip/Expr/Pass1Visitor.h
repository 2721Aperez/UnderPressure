#ifndef PASS1VISITOR_H_
#define PASS1VISITOR_H_

#include <iostream>

#include "wci/intermediate/SymTabStack.h"
#include "wci/intermediate/SymTabEntry.h"
#include "wci/intermediate/TypeSpec.h"

#include "ExprBaseVisitor.h"
#include "antlr4-runtime.h"
#include "ExprVisitor.h"

using namespace wci;
using namespace wci::intermediate;

class Pass1Visitor : public ExprBaseVisitor
{
private:
    SymTabStack *symtab_stack;
    SymTabEntry *program_id;
    vector<SymTabEntry *> variable_id_list;
    ofstream j_file;

public:
    Pass1Visitor();
    virtual ~Pass1Visitor();

    ostream& get_assembly_file();

    antlrcpp::Any visitProg(ExprParser::ProgContext *ctx) override;
    antlrcpp::Any visitVariable(ExprParser::VariableContext *ctx) override;
    antlrcpp::Any visitVar_dec(ExprParser::Var_decContext *ctx) override;
    antlrcpp::Any visitData_type(ExprParser::Data_typeContext *ctx) override;
//    antlrcpp::Any visitFunction_(ExprParser::Function_Context *ctx) override;
//    antlrcpp::Any visitFunction_call(ExprParser::Function_callContext *ctx) override;
//    antlrcpp::Any visitBarren_function(ExprParser::Barren_functionContext *ctx) override;
    antlrcpp::Any visitAddSubExpr(ExprParser::AddSubExprContext *ctx) override;
    antlrcpp::Any visitTestingExpr(ExprParser::TestingExprContext *ctx) override;
    antlrcpp::Any visitNumberExpr(ExprParser::NumberExprContext *ctx) override;
    antlrcpp::Any visitMulDivExpr(ExprParser::MulDivExprContext *ctx) override;
    antlrcpp::Any visitParenExpr(ExprParser::ParenExprContext *ctx) override;
    antlrcpp::Any visitIdentifierExpr(ExprParser::IdentifierExprContext *ctx) override;
    antlrcpp::Any visitIntConstExpr(ExprParser::IntConstExprContext *ctx) override;
    antlrcpp::Any visitFloatingConstExpr(ExprParser::FloatingConstExprContext *ctx) override;
};

#endif /* PASS1VISITOR_H_ */
