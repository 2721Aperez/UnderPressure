
// Generated from Expr.g4 by ANTLR 4.7.1


#include "ExprVisitor.h"

#include "ExprParser.h"


using namespace antlrcpp;
using namespace antlr4;

ExprParser::ExprParser(TokenStream *input) : Parser(input) {
  _interpreter = new atn::ParserATNSimulator(this, _atn, _decisionToDFA, _sharedContextCache);
}

ExprParser::~ExprParser() {
  delete _interpreter;
}

std::string ExprParser::getGrammarFileName() const {
  return "Expr.g4";
}

const std::vector<std::string>& ExprParser::getRuleNames() const {
  return _ruleNames;
}

dfa::Vocabulary& ExprParser::getVocabulary() const {
  return _vocabulary;
}


//----------------- ProgContext ------------------------------------------------------------------

ExprParser::ProgContext::ProgContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<ExprParser::StatementContext *> ExprParser::ProgContext::statement() {
  return getRuleContexts<ExprParser::StatementContext>();
}

ExprParser::StatementContext* ExprParser::ProgContext::statement(size_t i) {
  return getRuleContext<ExprParser::StatementContext>(i);
}


size_t ExprParser::ProgContext::getRuleIndex() const {
  return ExprParser::RuleProg;
}

antlrcpp::Any ExprParser::ProgContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ExprVisitor*>(visitor))
    return parserVisitor->visitProg(this);
  else
    return visitor->visitChildren(this);
}

ExprParser::ProgContext* ExprParser::prog() {
  ProgContext *_localctx = _tracker.createInstance<ProgContext>(_ctx, getState());
  enterRule(_localctx, 0, ExprParser::RuleProg);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(25); 
    _errHandler->sync(this);
    _la = _input->LA(1);
    do {
      setState(24);
      statement();
      setState(27); 
      _errHandler->sync(this);
      _la = _input->LA(1);
    } while ((((_la & ~ 0x3fULL) == 0) &&
      ((1ULL << _la) & ((1ULL << ExprParser::Loop)
      | (1ULL << ExprParser::If)
      | (1ULL << ExprParser::Function)
      | (1ULL << ExprParser::BARREN)
      | (1ULL << ExprParser::Digit)
      | (1ULL << ExprParser::Decimal)
      | (1ULL << ExprParser::ID))) != 0));
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- VariableContext ------------------------------------------------------------------

ExprParser::VariableContext::VariableContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* ExprParser::VariableContext::ID() {
  return getToken(ExprParser::ID, 0);
}


size_t ExprParser::VariableContext::getRuleIndex() const {
  return ExprParser::RuleVariable;
}

antlrcpp::Any ExprParser::VariableContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ExprVisitor*>(visitor))
    return parserVisitor->visitVariable(this);
  else
    return visitor->visitChildren(this);
}

ExprParser::VariableContext* ExprParser::variable() {
  VariableContext *_localctx = _tracker.createInstance<VariableContext>(_ctx, getState());
  enterRule(_localctx, 2, ExprParser::RuleVariable);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(29);
    match(ExprParser::ID);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Var_decContext ------------------------------------------------------------------

ExprParser::Var_decContext::Var_decContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

ExprParser::Data_typeContext* ExprParser::Var_decContext::data_type() {
  return getRuleContext<ExprParser::Data_typeContext>(0);
}

ExprParser::VariableContext* ExprParser::Var_decContext::variable() {
  return getRuleContext<ExprParser::VariableContext>(0);
}

ExprParser::ExprContext* ExprParser::Var_decContext::expr() {
  return getRuleContext<ExprParser::ExprContext>(0);
}


size_t ExprParser::Var_decContext::getRuleIndex() const {
  return ExprParser::RuleVar_dec;
}

antlrcpp::Any ExprParser::Var_decContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ExprVisitor*>(visitor))
    return parserVisitor->visitVar_dec(this);
  else
    return visitor->visitChildren(this);
}

ExprParser::Var_decContext* ExprParser::var_dec() {
  Var_decContext *_localctx = _tracker.createInstance<Var_decContext>(_ctx, getState());
  enterRule(_localctx, 4, ExprParser::RuleVar_dec);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(31);
    data_type();
    setState(32);
    variable();
    setState(35);
    _errHandler->sync(this);

    _la = _input->LA(1);
    if (_la == ExprParser::T__0) {
      setState(33);
      match(ExprParser::T__0);
      setState(34);
      expr(0);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Function_Context ------------------------------------------------------------------

ExprParser::Function_Context::Function_Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* ExprParser::Function_Context::Function() {
  return getToken(ExprParser::Function, 0);
}

std::vector<ExprParser::Data_typeContext *> ExprParser::Function_Context::data_type() {
  return getRuleContexts<ExprParser::Data_typeContext>();
}

ExprParser::Data_typeContext* ExprParser::Function_Context::data_type(size_t i) {
  return getRuleContext<ExprParser::Data_typeContext>(i);
}

std::vector<tree::TerminalNode *> ExprParser::Function_Context::ID() {
  return getTokens(ExprParser::ID);
}

tree::TerminalNode* ExprParser::Function_Context::ID(size_t i) {
  return getToken(ExprParser::ID, i);
}

ExprParser::VariableContext* ExprParser::Function_Context::variable() {
  return getRuleContext<ExprParser::VariableContext>(0);
}

tree::TerminalNode* ExprParser::Function_Context::SEND() {
  return getToken(ExprParser::SEND, 0);
}

std::vector<ExprParser::StatementContext *> ExprParser::Function_Context::statement() {
  return getRuleContexts<ExprParser::StatementContext>();
}

ExprParser::StatementContext* ExprParser::Function_Context::statement(size_t i) {
  return getRuleContext<ExprParser::StatementContext>(i);
}


size_t ExprParser::Function_Context::getRuleIndex() const {
  return ExprParser::RuleFunction_;
}

antlrcpp::Any ExprParser::Function_Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ExprVisitor*>(visitor))
    return parserVisitor->visitFunction_(this);
  else
    return visitor->visitChildren(this);
}

ExprParser::Function_Context* ExprParser::function_() {
  Function_Context *_localctx = _tracker.createInstance<Function_Context>(_ctx, getState());
  enterRule(_localctx, 6, ExprParser::RuleFunction_);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(37);
    match(ExprParser::Function);
    setState(38);
    data_type();
    setState(39);
    match(ExprParser::ID);
    setState(40);
    match(ExprParser::T__1);
    setState(41);
    data_type();
    setState(42);
    variable();
    setState(43);
    match(ExprParser::T__2);
    setState(44);
    match(ExprParser::T__3);
    setState(48);
    _errHandler->sync(this);
    _la = _input->LA(1);
    while ((((_la & ~ 0x3fULL) == 0) &&
      ((1ULL << _la) & ((1ULL << ExprParser::Loop)
      | (1ULL << ExprParser::If)
      | (1ULL << ExprParser::Function)
      | (1ULL << ExprParser::BARREN)
      | (1ULL << ExprParser::Digit)
      | (1ULL << ExprParser::Decimal)
      | (1ULL << ExprParser::ID))) != 0)) {
      setState(45);
      statement();
      setState(50);
      _errHandler->sync(this);
      _la = _input->LA(1);
    }
    setState(51);
    match(ExprParser::SEND);
    setState(52);
    match(ExprParser::ID);
    setState(53);
    match(ExprParser::T__4);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Function_callContext ------------------------------------------------------------------

ExprParser::Function_callContext::Function_callContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<tree::TerminalNode *> ExprParser::Function_callContext::ID() {
  return getTokens(ExprParser::ID);
}

tree::TerminalNode* ExprParser::Function_callContext::ID(size_t i) {
  return getToken(ExprParser::ID, i);
}


size_t ExprParser::Function_callContext::getRuleIndex() const {
  return ExprParser::RuleFunction_call;
}

antlrcpp::Any ExprParser::Function_callContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ExprVisitor*>(visitor))
    return parserVisitor->visitFunction_call(this);
  else
    return visitor->visitChildren(this);
}

ExprParser::Function_callContext* ExprParser::function_call() {
  Function_callContext *_localctx = _tracker.createInstance<Function_callContext>(_ctx, getState());
  enterRule(_localctx, 8, ExprParser::RuleFunction_call);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(55);
    match(ExprParser::ID);
    setState(56);
    match(ExprParser::T__1);
    setState(57);
    match(ExprParser::ID);
    setState(58);
    match(ExprParser::T__2);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Barren_functionContext ------------------------------------------------------------------

ExprParser::Barren_functionContext::Barren_functionContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* ExprParser::Barren_functionContext::BARREN() {
  return getToken(ExprParser::BARREN, 0);
}

tree::TerminalNode* ExprParser::Barren_functionContext::ID() {
  return getToken(ExprParser::ID, 0);
}

ExprParser::Data_typeContext* ExprParser::Barren_functionContext::data_type() {
  return getRuleContext<ExprParser::Data_typeContext>(0);
}

ExprParser::VariableContext* ExprParser::Barren_functionContext::variable() {
  return getRuleContext<ExprParser::VariableContext>(0);
}

std::vector<ExprParser::StatementContext *> ExprParser::Barren_functionContext::statement() {
  return getRuleContexts<ExprParser::StatementContext>();
}

ExprParser::StatementContext* ExprParser::Barren_functionContext::statement(size_t i) {
  return getRuleContext<ExprParser::StatementContext>(i);
}


size_t ExprParser::Barren_functionContext::getRuleIndex() const {
  return ExprParser::RuleBarren_function;
}

antlrcpp::Any ExprParser::Barren_functionContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ExprVisitor*>(visitor))
    return parserVisitor->visitBarren_function(this);
  else
    return visitor->visitChildren(this);
}

ExprParser::Barren_functionContext* ExprParser::barren_function() {
  Barren_functionContext *_localctx = _tracker.createInstance<Barren_functionContext>(_ctx, getState());
  enterRule(_localctx, 10, ExprParser::RuleBarren_function);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(60);
    match(ExprParser::BARREN);
    setState(61);
    match(ExprParser::ID);
    setState(62);
    match(ExprParser::T__1);
    setState(63);
    data_type();
    setState(64);
    variable();
    setState(65);
    match(ExprParser::T__2);
    setState(66);
    match(ExprParser::T__3);
    setState(70);
    _errHandler->sync(this);
    _la = _input->LA(1);
    while ((((_la & ~ 0x3fULL) == 0) &&
      ((1ULL << _la) & ((1ULL << ExprParser::Loop)
      | (1ULL << ExprParser::If)
      | (1ULL << ExprParser::Function)
      | (1ULL << ExprParser::BARREN)
      | (1ULL << ExprParser::Digit)
      | (1ULL << ExprParser::Decimal)
      | (1ULL << ExprParser::ID))) != 0)) {
      setState(67);
      statement();
      setState(72);
      _errHandler->sync(this);
      _la = _input->LA(1);
    }
    setState(73);
    match(ExprParser::T__4);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Loop_statementContext ------------------------------------------------------------------

ExprParser::Loop_statementContext::Loop_statementContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* ExprParser::Loop_statementContext::Loop() {
  return getToken(ExprParser::Loop, 0);
}

ExprParser::StatementContext* ExprParser::Loop_statementContext::statement() {
  return getRuleContext<ExprParser::StatementContext>(0);
}

tree::TerminalNode* ExprParser::Loop_statementContext::Stop() {
  return getToken(ExprParser::Stop, 0);
}

ExprParser::ExprContext* ExprParser::Loop_statementContext::expr() {
  return getRuleContext<ExprParser::ExprContext>(0);
}


size_t ExprParser::Loop_statementContext::getRuleIndex() const {
  return ExprParser::RuleLoop_statement;
}

antlrcpp::Any ExprParser::Loop_statementContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ExprVisitor*>(visitor))
    return parserVisitor->visitLoop_statement(this);
  else
    return visitor->visitChildren(this);
}

ExprParser::Loop_statementContext* ExprParser::loop_statement() {
  Loop_statementContext *_localctx = _tracker.createInstance<Loop_statementContext>(_ctx, getState());
  enterRule(_localctx, 12, ExprParser::RuleLoop_statement);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(75);
    match(ExprParser::Loop);
    setState(76);
    statement();
    setState(77);
    match(ExprParser::Stop);
    setState(78);
    expr(0);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- If_statementContext ------------------------------------------------------------------

ExprParser::If_statementContext::If_statementContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* ExprParser::If_statementContext::If() {
  return getToken(ExprParser::If, 0);
}

ExprParser::ExprContext* ExprParser::If_statementContext::expr() {
  return getRuleContext<ExprParser::ExprContext>(0);
}

ExprParser::StatementContext* ExprParser::If_statementContext::statement() {
  return getRuleContext<ExprParser::StatementContext>(0);
}


size_t ExprParser::If_statementContext::getRuleIndex() const {
  return ExprParser::RuleIf_statement;
}

antlrcpp::Any ExprParser::If_statementContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ExprVisitor*>(visitor))
    return parserVisitor->visitIf_statement(this);
  else
    return visitor->visitChildren(this);
}

ExprParser::If_statementContext* ExprParser::if_statement() {
  If_statementContext *_localctx = _tracker.createInstance<If_statementContext>(_ctx, getState());
  enterRule(_localctx, 14, ExprParser::RuleIf_statement);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(80);
    match(ExprParser::If);
    setState(81);
    match(ExprParser::T__1);
    setState(82);
    expr(0);
    setState(83);
    match(ExprParser::T__2);
    setState(84);
    statement();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- StatementContext ------------------------------------------------------------------

ExprParser::StatementContext::StatementContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* ExprParser::StatementContext::ID() {
  return getToken(ExprParser::ID, 0);
}

ExprParser::ExprContext* ExprParser::StatementContext::expr() {
  return getRuleContext<ExprParser::ExprContext>(0);
}

ExprParser::Var_decContext* ExprParser::StatementContext::var_dec() {
  return getRuleContext<ExprParser::Var_decContext>(0);
}

ExprParser::If_statementContext* ExprParser::StatementContext::if_statement() {
  return getRuleContext<ExprParser::If_statementContext>(0);
}

ExprParser::Loop_statementContext* ExprParser::StatementContext::loop_statement() {
  return getRuleContext<ExprParser::Loop_statementContext>(0);
}

ExprParser::Function_Context* ExprParser::StatementContext::function_() {
  return getRuleContext<ExprParser::Function_Context>(0);
}

ExprParser::Function_callContext* ExprParser::StatementContext::function_call() {
  return getRuleContext<ExprParser::Function_callContext>(0);
}

ExprParser::Barren_functionContext* ExprParser::StatementContext::barren_function() {
  return getRuleContext<ExprParser::Barren_functionContext>(0);
}


size_t ExprParser::StatementContext::getRuleIndex() const {
  return ExprParser::RuleStatement;
}

antlrcpp::Any ExprParser::StatementContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ExprVisitor*>(visitor))
    return parserVisitor->visitStatement(this);
  else
    return visitor->visitChildren(this);
}

ExprParser::StatementContext* ExprParser::statement() {
  StatementContext *_localctx = _tracker.createInstance<StatementContext>(_ctx, getState());
  enterRule(_localctx, 16, ExprParser::RuleStatement);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(95);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 4, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(86);
      match(ExprParser::ID);
      setState(87);
      match(ExprParser::T__0);
      setState(88);
      expr(0);
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(89);
      var_dec();
      break;
    }

    case 3: {
      enterOuterAlt(_localctx, 3);
      setState(90);
      if_statement();
      break;
    }

    case 4: {
      enterOuterAlt(_localctx, 4);
      setState(91);
      loop_statement();
      break;
    }

    case 5: {
      enterOuterAlt(_localctx, 5);
      setState(92);
      function_();
      break;
    }

    case 6: {
      enterOuterAlt(_localctx, 6);
      setState(93);
      function_call();
      break;
    }

    case 7: {
      enterOuterAlt(_localctx, 7);
      setState(94);
      barren_function();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ExprContext ------------------------------------------------------------------

ExprParser::ExprContext::ExprContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t ExprParser::ExprContext::getRuleIndex() const {
  return ExprParser::RuleExpr;
}

void ExprParser::ExprContext::copyFrom(ExprContext *ctx) {
  ParserRuleContext::copyFrom(ctx);
  this->type = ctx->type;
}

//----------------- AddSubExprContext ------------------------------------------------------------------

std::vector<ExprParser::ExprContext *> ExprParser::AddSubExprContext::expr() {
  return getRuleContexts<ExprParser::ExprContext>();
}

ExprParser::ExprContext* ExprParser::AddSubExprContext::expr(size_t i) {
  return getRuleContext<ExprParser::ExprContext>(i);
}

tree::TerminalNode* ExprParser::AddSubExprContext::ADD_SUB() {
  return getToken(ExprParser::ADD_SUB, 0);
}

ExprParser::AddSubExprContext::AddSubExprContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ExprParser::AddSubExprContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ExprVisitor*>(visitor))
    return parserVisitor->visitAddSubExpr(this);
  else
    return visitor->visitChildren(this);
}
//----------------- TestingExprContext ------------------------------------------------------------------

std::vector<ExprParser::ExprContext *> ExprParser::TestingExprContext::expr() {
  return getRuleContexts<ExprParser::ExprContext>();
}

ExprParser::ExprContext* ExprParser::TestingExprContext::expr(size_t i) {
  return getRuleContext<ExprParser::ExprContext>(i);
}

tree::TerminalNode* ExprParser::TestingExprContext::Testing() {
  return getToken(ExprParser::Testing, 0);
}

ExprParser::TestingExprContext::TestingExprContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ExprParser::TestingExprContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ExprVisitor*>(visitor))
    return parserVisitor->visitTestingExpr(this);
  else
    return visitor->visitChildren(this);
}
//----------------- NumberExprContext ------------------------------------------------------------------

ExprParser::NumbersContext* ExprParser::NumberExprContext::numbers() {
  return getRuleContext<ExprParser::NumbersContext>(0);
}

ExprParser::NumberExprContext::NumberExprContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ExprParser::NumberExprContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ExprVisitor*>(visitor))
    return parserVisitor->visitNumberExpr(this);
  else
    return visitor->visitChildren(this);
}
//----------------- MulDivExprContext ------------------------------------------------------------------

std::vector<ExprParser::ExprContext *> ExprParser::MulDivExprContext::expr() {
  return getRuleContexts<ExprParser::ExprContext>();
}

ExprParser::ExprContext* ExprParser::MulDivExprContext::expr(size_t i) {
  return getRuleContext<ExprParser::ExprContext>(i);
}

tree::TerminalNode* ExprParser::MulDivExprContext::MUL_DIV() {
  return getToken(ExprParser::MUL_DIV, 0);
}

ExprParser::MulDivExprContext::MulDivExprContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ExprParser::MulDivExprContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ExprVisitor*>(visitor))
    return parserVisitor->visitMulDivExpr(this);
  else
    return visitor->visitChildren(this);
}
//----------------- ParenExprContext ------------------------------------------------------------------

ExprParser::ExprContext* ExprParser::ParenExprContext::expr() {
  return getRuleContext<ExprParser::ExprContext>(0);
}

ExprParser::ParenExprContext::ParenExprContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ExprParser::ParenExprContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ExprVisitor*>(visitor))
    return parserVisitor->visitParenExpr(this);
  else
    return visitor->visitChildren(this);
}
//----------------- IdentifierExprContext ------------------------------------------------------------------

tree::TerminalNode* ExprParser::IdentifierExprContext::ID() {
  return getToken(ExprParser::ID, 0);
}

ExprParser::IdentifierExprContext::IdentifierExprContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ExprParser::IdentifierExprContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ExprVisitor*>(visitor))
    return parserVisitor->visitIdentifierExpr(this);
  else
    return visitor->visitChildren(this);
}

ExprParser::ExprContext* ExprParser::expr() {
   return expr(0);
}

ExprParser::ExprContext* ExprParser::expr(int precedence) {
  ParserRuleContext *parentContext = _ctx;
  size_t parentState = getState();
  ExprParser::ExprContext *_localctx = _tracker.createInstance<ExprContext>(_ctx, parentState);
  ExprParser::ExprContext *previousContext = _localctx;
  size_t startState = 18;
  enterRecursionRule(_localctx, 18, ExprParser::RuleExpr, precedence);

    

  auto onExit = finally([=] {
    unrollRecursionContexts(parentContext);
  });
  try {
    size_t alt;
    enterOuterAlt(_localctx, 1);
    setState(104);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case ExprParser::Numb:
      case ExprParser::Floating: {
        _localctx = _tracker.createInstance<NumberExprContext>(_localctx);
        _ctx = _localctx;
        previousContext = _localctx;

        setState(98);
        numbers();
        break;
      }

      case ExprParser::ID: {
        _localctx = _tracker.createInstance<IdentifierExprContext>(_localctx);
        _ctx = _localctx;
        previousContext = _localctx;
        setState(99);
        match(ExprParser::ID);
        break;
      }

      case ExprParser::T__1: {
        _localctx = _tracker.createInstance<ParenExprContext>(_localctx);
        _ctx = _localctx;
        previousContext = _localctx;
        setState(100);
        match(ExprParser::T__1);
        setState(101);
        expr(0);
        setState(102);
        match(ExprParser::T__2);
        break;
      }

    default:
      throw NoViableAltException(this);
    }
    _ctx->stop = _input->LT(-1);
    setState(117);
    _errHandler->sync(this);
    alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 7, _ctx);
    while (alt != 2 && alt != atn::ATN::INVALID_ALT_NUMBER) {
      if (alt == 1) {
        if (!_parseListeners.empty())
          triggerExitRuleEvent();
        previousContext = _localctx;
        setState(115);
        _errHandler->sync(this);
        switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 6, _ctx)) {
        case 1: {
          auto newContext = _tracker.createInstance<MulDivExprContext>(_tracker.createInstance<ExprContext>(parentContext, parentState));
          _localctx = newContext;
          pushNewRecursionContext(newContext, startState, RuleExpr);
          setState(106);

          if (!(precpred(_ctx, 6))) throw FailedPredicateException(this, "precpred(_ctx, 6)");
          setState(107);
          match(ExprParser::MUL_DIV);
          setState(108);
          expr(7);
          break;
        }

        case 2: {
          auto newContext = _tracker.createInstance<AddSubExprContext>(_tracker.createInstance<ExprContext>(parentContext, parentState));
          _localctx = newContext;
          pushNewRecursionContext(newContext, startState, RuleExpr);
          setState(109);

          if (!(precpred(_ctx, 5))) throw FailedPredicateException(this, "precpred(_ctx, 5)");
          setState(110);
          match(ExprParser::ADD_SUB);
          setState(111);
          expr(6);
          break;
        }

        case 3: {
          auto newContext = _tracker.createInstance<TestingExprContext>(_tracker.createInstance<ExprContext>(parentContext, parentState));
          _localctx = newContext;
          pushNewRecursionContext(newContext, startState, RuleExpr);
          setState(112);

          if (!(precpred(_ctx, 2))) throw FailedPredicateException(this, "precpred(_ctx, 2)");
          setState(113);
          match(ExprParser::Testing);
          setState(114);
          expr(3);
          break;
        }

        } 
      }
      setState(119);
      _errHandler->sync(this);
      alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 7, _ctx);
    }
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }
  return _localctx;
}

//----------------- NumbersContext ------------------------------------------------------------------

ExprParser::NumbersContext::NumbersContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t ExprParser::NumbersContext::getRuleIndex() const {
  return ExprParser::RuleNumbers;
}

void ExprParser::NumbersContext::copyFrom(NumbersContext *ctx) {
  ParserRuleContext::copyFrom(ctx);
  this->type = ctx->type;
}

//----------------- FloatingConstExprContext ------------------------------------------------------------------

tree::TerminalNode* ExprParser::FloatingConstExprContext::Floating() {
  return getToken(ExprParser::Floating, 0);
}

ExprParser::FloatingConstExprContext::FloatingConstExprContext(NumbersContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ExprParser::FloatingConstExprContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ExprVisitor*>(visitor))
    return parserVisitor->visitFloatingConstExpr(this);
  else
    return visitor->visitChildren(this);
}
//----------------- IntConstExprContext ------------------------------------------------------------------

tree::TerminalNode* ExprParser::IntConstExprContext::Numb() {
  return getToken(ExprParser::Numb, 0);
}

ExprParser::IntConstExprContext::IntConstExprContext(NumbersContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ExprParser::IntConstExprContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ExprVisitor*>(visitor))
    return parserVisitor->visitIntConstExpr(this);
  else
    return visitor->visitChildren(this);
}
ExprParser::NumbersContext* ExprParser::numbers() {
  NumbersContext *_localctx = _tracker.createInstance<NumbersContext>(_ctx, getState());
  enterRule(_localctx, 20, ExprParser::RuleNumbers);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(122);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case ExprParser::Numb: {
        _localctx = dynamic_cast<NumbersContext *>(_tracker.createInstance<ExprParser::IntConstExprContext>(_localctx));
        enterOuterAlt(_localctx, 1);
        setState(120);
        match(ExprParser::Numb);
        break;
      }

      case ExprParser::Floating: {
        _localctx = dynamic_cast<NumbersContext *>(_tracker.createInstance<ExprParser::FloatingConstExprContext>(_localctx));
        enterOuterAlt(_localctx, 2);
        setState(121);
        match(ExprParser::Floating);
        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Data_typeContext ------------------------------------------------------------------

ExprParser::Data_typeContext::Data_typeContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* ExprParser::Data_typeContext::Digit() {
  return getToken(ExprParser::Digit, 0);
}

tree::TerminalNode* ExprParser::Data_typeContext::Decimal() {
  return getToken(ExprParser::Decimal, 0);
}


size_t ExprParser::Data_typeContext::getRuleIndex() const {
  return ExprParser::RuleData_type;
}

antlrcpp::Any ExprParser::Data_typeContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ExprVisitor*>(visitor))
    return parserVisitor->visitData_type(this);
  else
    return visitor->visitChildren(this);
}

ExprParser::Data_typeContext* ExprParser::data_type() {
  Data_typeContext *_localctx = _tracker.createInstance<Data_typeContext>(_ctx, getState());
  enterRule(_localctx, 22, ExprParser::RuleData_type);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(124);
    _la = _input->LA(1);
    if (!(_la == ExprParser::Digit

    || _la == ExprParser::Decimal)) {
    _errHandler->recoverInline(this);
    }
    else {
      _errHandler->reportMatch(this);
      consume();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

bool ExprParser::sempred(RuleContext *context, size_t ruleIndex, size_t predicateIndex) {
  switch (ruleIndex) {
    case 9: return exprSempred(dynamic_cast<ExprContext *>(context), predicateIndex);

  default:
    break;
  }
  return true;
}

bool ExprParser::exprSempred(ExprContext *_localctx, size_t predicateIndex) {
  switch (predicateIndex) {
    case 0: return precpred(_ctx, 6);
    case 1: return precpred(_ctx, 5);
    case 2: return precpred(_ctx, 2);

  default:
    break;
  }
  return true;
}

// Static vars and initialization.
std::vector<dfa::DFA> ExprParser::_decisionToDFA;
atn::PredictionContextCache ExprParser::_sharedContextCache;

// We own the ATN which in turn owns the ATN states.
atn::ATN ExprParser::_atn;
std::vector<uint16_t> ExprParser::_serializedATN;

std::vector<std::string> ExprParser::_ruleNames = {
  "prog", "variable", "var_dec", "function_", "function_call", "barren_function", 
  "loop_statement", "if_statement", "statement", "expr", "numbers", "data_type"
};

std::vector<std::string> ExprParser::_literalNames = {
  "", "'='", "'('", "')'", "'{'", "'}'", "", "", "'loop'", "'stop'", "'if'", 
  "'function'", "'barren'", "'digit'", "'decimal'", "'send'", "", "", "", 
  "", "'*'", "'/'", "'+'", "'-'", "", "'?='", "'X='", "'<'", "'<='", "'>'", 
  "'>='"
};

std::vector<std::string> ExprParser::_symbolicNames = {
  "", "", "", "", "", "", "MUL_DIV", "ADD_SUB", "Loop", "Stop", "If", "Function", 
  "BARREN", "Digit", "Decimal", "SEND", "ID", "Numb", "Floating", "WS", 
  "MUL", "DIV", "ADD", "SUB", "Testing", "EQ", "NOT_EQ", "LT", "LE", "GT", 
  "GE"
};

dfa::Vocabulary ExprParser::_vocabulary(_literalNames, _symbolicNames);

std::vector<std::string> ExprParser::_tokenNames;

ExprParser::Initializer::Initializer() {
	for (size_t i = 0; i < _symbolicNames.size(); ++i) {
		std::string name = _vocabulary.getLiteralName(i);
		if (name.empty()) {
			name = _vocabulary.getSymbolicName(i);
		}

		if (name.empty()) {
			_tokenNames.push_back("<INVALID>");
		} else {
      _tokenNames.push_back(name);
    }
	}

  _serializedATN = {
    0x3, 0x608b, 0xa72a, 0x8133, 0xb9ed, 0x417c, 0x3be7, 0x7786, 0x5964, 
    0x3, 0x20, 0x81, 0x4, 0x2, 0x9, 0x2, 0x4, 0x3, 0x9, 0x3, 0x4, 0x4, 0x9, 
    0x4, 0x4, 0x5, 0x9, 0x5, 0x4, 0x6, 0x9, 0x6, 0x4, 0x7, 0x9, 0x7, 0x4, 
    0x8, 0x9, 0x8, 0x4, 0x9, 0x9, 0x9, 0x4, 0xa, 0x9, 0xa, 0x4, 0xb, 0x9, 
    0xb, 0x4, 0xc, 0x9, 0xc, 0x4, 0xd, 0x9, 0xd, 0x3, 0x2, 0x6, 0x2, 0x1c, 
    0xa, 0x2, 0xd, 0x2, 0xe, 0x2, 0x1d, 0x3, 0x3, 0x3, 0x3, 0x3, 0x4, 0x3, 
    0x4, 0x3, 0x4, 0x3, 0x4, 0x5, 0x4, 0x26, 0xa, 0x4, 0x3, 0x5, 0x3, 0x5, 
    0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 
    0x7, 0x5, 0x31, 0xa, 0x5, 0xc, 0x5, 0xe, 0x5, 0x34, 0xb, 0x5, 0x3, 0x5, 
    0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x6, 0x3, 0x6, 0x3, 0x6, 0x3, 0x6, 
    0x3, 0x6, 0x3, 0x7, 0x3, 0x7, 0x3, 0x7, 0x3, 0x7, 0x3, 0x7, 0x3, 0x7, 
    0x3, 0x7, 0x3, 0x7, 0x7, 0x7, 0x47, 0xa, 0x7, 0xc, 0x7, 0xe, 0x7, 0x4a, 
    0xb, 0x7, 0x3, 0x7, 0x3, 0x7, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 
    0x3, 0x8, 0x3, 0x9, 0x3, 0x9, 0x3, 0x9, 0x3, 0x9, 0x3, 0x9, 0x3, 0x9, 
    0x3, 0xa, 0x3, 0xa, 0x3, 0xa, 0x3, 0xa, 0x3, 0xa, 0x3, 0xa, 0x3, 0xa, 
    0x3, 0xa, 0x3, 0xa, 0x5, 0xa, 0x62, 0xa, 0xa, 0x3, 0xb, 0x3, 0xb, 0x3, 
    0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x5, 0xb, 0x6b, 0xa, 0xb, 
    0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 
    0x3, 0xb, 0x3, 0xb, 0x7, 0xb, 0x76, 0xa, 0xb, 0xc, 0xb, 0xe, 0xb, 0x79, 
    0xb, 0xb, 0x3, 0xc, 0x3, 0xc, 0x5, 0xc, 0x7d, 0xa, 0xc, 0x3, 0xd, 0x3, 
    0xd, 0x3, 0xd, 0x2, 0x3, 0x14, 0xe, 0x2, 0x4, 0x6, 0x8, 0xa, 0xc, 0xe, 
    0x10, 0x12, 0x14, 0x16, 0x18, 0x2, 0x3, 0x3, 0x2, 0xf, 0x10, 0x2, 0x84, 
    0x2, 0x1b, 0x3, 0x2, 0x2, 0x2, 0x4, 0x1f, 0x3, 0x2, 0x2, 0x2, 0x6, 0x21, 
    0x3, 0x2, 0x2, 0x2, 0x8, 0x27, 0x3, 0x2, 0x2, 0x2, 0xa, 0x39, 0x3, 0x2, 
    0x2, 0x2, 0xc, 0x3e, 0x3, 0x2, 0x2, 0x2, 0xe, 0x4d, 0x3, 0x2, 0x2, 0x2, 
    0x10, 0x52, 0x3, 0x2, 0x2, 0x2, 0x12, 0x61, 0x3, 0x2, 0x2, 0x2, 0x14, 
    0x6a, 0x3, 0x2, 0x2, 0x2, 0x16, 0x7c, 0x3, 0x2, 0x2, 0x2, 0x18, 0x7e, 
    0x3, 0x2, 0x2, 0x2, 0x1a, 0x1c, 0x5, 0x12, 0xa, 0x2, 0x1b, 0x1a, 0x3, 
    0x2, 0x2, 0x2, 0x1c, 0x1d, 0x3, 0x2, 0x2, 0x2, 0x1d, 0x1b, 0x3, 0x2, 
    0x2, 0x2, 0x1d, 0x1e, 0x3, 0x2, 0x2, 0x2, 0x1e, 0x3, 0x3, 0x2, 0x2, 
    0x2, 0x1f, 0x20, 0x7, 0x12, 0x2, 0x2, 0x20, 0x5, 0x3, 0x2, 0x2, 0x2, 
    0x21, 0x22, 0x5, 0x18, 0xd, 0x2, 0x22, 0x25, 0x5, 0x4, 0x3, 0x2, 0x23, 
    0x24, 0x7, 0x3, 0x2, 0x2, 0x24, 0x26, 0x5, 0x14, 0xb, 0x2, 0x25, 0x23, 
    0x3, 0x2, 0x2, 0x2, 0x25, 0x26, 0x3, 0x2, 0x2, 0x2, 0x26, 0x7, 0x3, 
    0x2, 0x2, 0x2, 0x27, 0x28, 0x7, 0xd, 0x2, 0x2, 0x28, 0x29, 0x5, 0x18, 
    0xd, 0x2, 0x29, 0x2a, 0x7, 0x12, 0x2, 0x2, 0x2a, 0x2b, 0x7, 0x4, 0x2, 
    0x2, 0x2b, 0x2c, 0x5, 0x18, 0xd, 0x2, 0x2c, 0x2d, 0x5, 0x4, 0x3, 0x2, 
    0x2d, 0x2e, 0x7, 0x5, 0x2, 0x2, 0x2e, 0x32, 0x7, 0x6, 0x2, 0x2, 0x2f, 
    0x31, 0x5, 0x12, 0xa, 0x2, 0x30, 0x2f, 0x3, 0x2, 0x2, 0x2, 0x31, 0x34, 
    0x3, 0x2, 0x2, 0x2, 0x32, 0x30, 0x3, 0x2, 0x2, 0x2, 0x32, 0x33, 0x3, 
    0x2, 0x2, 0x2, 0x33, 0x35, 0x3, 0x2, 0x2, 0x2, 0x34, 0x32, 0x3, 0x2, 
    0x2, 0x2, 0x35, 0x36, 0x7, 0x11, 0x2, 0x2, 0x36, 0x37, 0x7, 0x12, 0x2, 
    0x2, 0x37, 0x38, 0x7, 0x7, 0x2, 0x2, 0x38, 0x9, 0x3, 0x2, 0x2, 0x2, 
    0x39, 0x3a, 0x7, 0x12, 0x2, 0x2, 0x3a, 0x3b, 0x7, 0x4, 0x2, 0x2, 0x3b, 
    0x3c, 0x7, 0x12, 0x2, 0x2, 0x3c, 0x3d, 0x7, 0x5, 0x2, 0x2, 0x3d, 0xb, 
    0x3, 0x2, 0x2, 0x2, 0x3e, 0x3f, 0x7, 0xe, 0x2, 0x2, 0x3f, 0x40, 0x7, 
    0x12, 0x2, 0x2, 0x40, 0x41, 0x7, 0x4, 0x2, 0x2, 0x41, 0x42, 0x5, 0x18, 
    0xd, 0x2, 0x42, 0x43, 0x5, 0x4, 0x3, 0x2, 0x43, 0x44, 0x7, 0x5, 0x2, 
    0x2, 0x44, 0x48, 0x7, 0x6, 0x2, 0x2, 0x45, 0x47, 0x5, 0x12, 0xa, 0x2, 
    0x46, 0x45, 0x3, 0x2, 0x2, 0x2, 0x47, 0x4a, 0x3, 0x2, 0x2, 0x2, 0x48, 
    0x46, 0x3, 0x2, 0x2, 0x2, 0x48, 0x49, 0x3, 0x2, 0x2, 0x2, 0x49, 0x4b, 
    0x3, 0x2, 0x2, 0x2, 0x4a, 0x48, 0x3, 0x2, 0x2, 0x2, 0x4b, 0x4c, 0x7, 
    0x7, 0x2, 0x2, 0x4c, 0xd, 0x3, 0x2, 0x2, 0x2, 0x4d, 0x4e, 0x7, 0xa, 
    0x2, 0x2, 0x4e, 0x4f, 0x5, 0x12, 0xa, 0x2, 0x4f, 0x50, 0x7, 0xb, 0x2, 
    0x2, 0x50, 0x51, 0x5, 0x14, 0xb, 0x2, 0x51, 0xf, 0x3, 0x2, 0x2, 0x2, 
    0x52, 0x53, 0x7, 0xc, 0x2, 0x2, 0x53, 0x54, 0x7, 0x4, 0x2, 0x2, 0x54, 
    0x55, 0x5, 0x14, 0xb, 0x2, 0x55, 0x56, 0x7, 0x5, 0x2, 0x2, 0x56, 0x57, 
    0x5, 0x12, 0xa, 0x2, 0x57, 0x11, 0x3, 0x2, 0x2, 0x2, 0x58, 0x59, 0x7, 
    0x12, 0x2, 0x2, 0x59, 0x5a, 0x7, 0x3, 0x2, 0x2, 0x5a, 0x62, 0x5, 0x14, 
    0xb, 0x2, 0x5b, 0x62, 0x5, 0x6, 0x4, 0x2, 0x5c, 0x62, 0x5, 0x10, 0x9, 
    0x2, 0x5d, 0x62, 0x5, 0xe, 0x8, 0x2, 0x5e, 0x62, 0x5, 0x8, 0x5, 0x2, 
    0x5f, 0x62, 0x5, 0xa, 0x6, 0x2, 0x60, 0x62, 0x5, 0xc, 0x7, 0x2, 0x61, 
    0x58, 0x3, 0x2, 0x2, 0x2, 0x61, 0x5b, 0x3, 0x2, 0x2, 0x2, 0x61, 0x5c, 
    0x3, 0x2, 0x2, 0x2, 0x61, 0x5d, 0x3, 0x2, 0x2, 0x2, 0x61, 0x5e, 0x3, 
    0x2, 0x2, 0x2, 0x61, 0x5f, 0x3, 0x2, 0x2, 0x2, 0x61, 0x60, 0x3, 0x2, 
    0x2, 0x2, 0x62, 0x13, 0x3, 0x2, 0x2, 0x2, 0x63, 0x64, 0x8, 0xb, 0x1, 
    0x2, 0x64, 0x6b, 0x5, 0x16, 0xc, 0x2, 0x65, 0x6b, 0x7, 0x12, 0x2, 0x2, 
    0x66, 0x67, 0x7, 0x4, 0x2, 0x2, 0x67, 0x68, 0x5, 0x14, 0xb, 0x2, 0x68, 
    0x69, 0x7, 0x5, 0x2, 0x2, 0x69, 0x6b, 0x3, 0x2, 0x2, 0x2, 0x6a, 0x63, 
    0x3, 0x2, 0x2, 0x2, 0x6a, 0x65, 0x3, 0x2, 0x2, 0x2, 0x6a, 0x66, 0x3, 
    0x2, 0x2, 0x2, 0x6b, 0x77, 0x3, 0x2, 0x2, 0x2, 0x6c, 0x6d, 0xc, 0x8, 
    0x2, 0x2, 0x6d, 0x6e, 0x7, 0x8, 0x2, 0x2, 0x6e, 0x76, 0x5, 0x14, 0xb, 
    0x9, 0x6f, 0x70, 0xc, 0x7, 0x2, 0x2, 0x70, 0x71, 0x7, 0x9, 0x2, 0x2, 
    0x71, 0x76, 0x5, 0x14, 0xb, 0x8, 0x72, 0x73, 0xc, 0x4, 0x2, 0x2, 0x73, 
    0x74, 0x7, 0x1a, 0x2, 0x2, 0x74, 0x76, 0x5, 0x14, 0xb, 0x5, 0x75, 0x6c, 
    0x3, 0x2, 0x2, 0x2, 0x75, 0x6f, 0x3, 0x2, 0x2, 0x2, 0x75, 0x72, 0x3, 
    0x2, 0x2, 0x2, 0x76, 0x79, 0x3, 0x2, 0x2, 0x2, 0x77, 0x75, 0x3, 0x2, 
    0x2, 0x2, 0x77, 0x78, 0x3, 0x2, 0x2, 0x2, 0x78, 0x15, 0x3, 0x2, 0x2, 
    0x2, 0x79, 0x77, 0x3, 0x2, 0x2, 0x2, 0x7a, 0x7d, 0x7, 0x13, 0x2, 0x2, 
    0x7b, 0x7d, 0x7, 0x14, 0x2, 0x2, 0x7c, 0x7a, 0x3, 0x2, 0x2, 0x2, 0x7c, 
    0x7b, 0x3, 0x2, 0x2, 0x2, 0x7d, 0x17, 0x3, 0x2, 0x2, 0x2, 0x7e, 0x7f, 
    0x9, 0x2, 0x2, 0x2, 0x7f, 0x19, 0x3, 0x2, 0x2, 0x2, 0xb, 0x1d, 0x25, 
    0x32, 0x48, 0x61, 0x6a, 0x75, 0x77, 0x7c, 
  };

  atn::ATNDeserializer deserializer;
  _atn = deserializer.deserialize(_serializedATN);

  size_t count = _atn.getNumberOfDecisions();
  _decisionToDFA.reserve(count);
  for (size_t i = 0; i < count; i++) { 
    _decisionToDFA.emplace_back(_atn.getDecisionState(i), i);
  }
}

ExprParser::Initializer ExprParser::_init;
