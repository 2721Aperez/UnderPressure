#include <iostream>
#include <string>

#include "Pass2Visitor.h"
#include "wci/intermediate/SymTabStack.h"
#include "wci/intermediate/SymTabEntry.h"
#include "wci/intermediate/TypeSpec.h"
#include "wci/intermediate/symtabimpl/Predefined.h"

using namespace wci;
using namespace wci::intermediate;
using namespace wci::intermediate::symtabimpl;

int label = 0;

Pass2Visitor::Pass2Visitor(ostream& j_file)
    : program_name(""), j_file(j_file)
{
}

Pass2Visitor::~Pass2Visitor() {}

antlrcpp::Any Pass2Visitor::visitProg(ExprParser::ProgContext *ctx)
{
	program_name = "NewProgram";

	//Emit main program header
	j_file << endl;
	j_file << ".method public static main([Ljava/lang/String;)V" << endl;
	j_file << endl;
	j_file << "\tnew RunTimer" << endl;
	j_file << "\tdup" << endl;
	j_file << "\tinvokenonvirtual RunTimer/<init>()V" << endl;
	j_file << "\tputstatic		" << program_name
		   << "/_runTimer LRunTimer;" << endl;
	j_file << "\tnew PascalTextIn" << endl;
	j_file << "\tdup" << endl;
	j_file << "\tinvokenonvirtual PascalTextIn/<init>()V" << endl;
	j_file << "\tputstatic		" + program_name
		   << "/_standardIn LPascalTextIn;" << endl;

    auto value = visitChildren(ctx);

    //Emit main program epilogue
    j_file << endl;
    j_file << "\tgetstatic     " << program_name
               << "/_runTimer LRunTimer;" << endl;
    j_file << "\tinvokevirtual RunTimer.printElapsedTime()V" << endl;
    j_file << endl;
    j_file << "\treturn" << endl;
    j_file << endl;
    j_file << ".limit locals 32" << endl;
    j_file << ".limit stack 32" << endl;
    j_file << ".end method" << endl;

    //j_file.close();
    return value;
}

antlrcpp::Any Pass2Visitor::visitStatement(ExprParser::StatementContext *ctx)
{
    j_file << endl << ctx->getText() << endl << endl;

    return visitChildren(ctx);
}

antlrcpp::Any Pass2Visitor::visitVar_dec(ExprParser::Var_decContext *ctx)
{
	string type_name = ctx->data_type()->toString();
	string type_indicator;

	if (type_name == "digit")
	{
		type_indicator = "D";
		j_file << "\tldc" << ctx->data_type()->toString();
	}
	else if (type_name == "decimal")
	{
		type_indicator = "R";
		j_file << "\tldc" << ctx->data_type()->toString();
	}
	else
	{
		type_indicator = "?";
	}

	//Emit field instruction
	j_file << "\tputstatic\t" << program_name
		   << "/" << ctx->variable()->toString()
		       << " " << type_indicator << endl;

	return visitChildren(ctx);
}

antlrcpp::Any Pass2Visitor::visitAddSubExpr(ExprParser::AddSubExprContext *ctx)
{
    auto value = visitChildren(ctx);

    TypeSpec *type1 = ctx->expr(0)->type;
    TypeSpec *type2 = ctx->expr(1)->type;

    bool integer_mode =    (type1 == Predefined::integer_type)
                        && (type2 == Predefined::integer_type);
    bool real_mode    =    (type1 == Predefined::real_type)
                        && (type2 == Predefined::real_type);

    string op = ctx->ADD_SUB()->getText();
    string opcode;

    if (op == "+")
    {
        opcode = integer_mode ? "iadd"
               : real_mode    ? "fadd"
               :                "????";
    }
    else
    {
        opcode = integer_mode ? "isub"
               : real_mode    ? "fsub"
               :                "????";
    }

    // Emit an add or subtract instruction.
    j_file << "\t" << opcode << endl;

    return value;
}

antlrcpp::Any Pass2Visitor::visitTestingExpr(ExprParser::TestingExprContext *ctx)
{
    auto value = visitChildren(ctx);

    TypeSpec *type1 = ctx->expr(0)->type;
    TypeSpec *type2 = ctx->expr(1)->type;

    bool integer_mode =    (type1 == Predefined::integer_type)
                        && (type2 == Predefined::integer_type);
    bool real_mode    =    (type1 == Predefined::real_type)
                        && (type2 == Predefined::real_type);

    string op = ctx->Testing()->getText();
    string opcode;

    if(integer_mode)
    {
    	if (op == "?=") j_file << "\tif_icmpeq Label" << to_string(label) << endl;
    	else if (op == "X=") j_file << "\tif_icmpne Label" << to_string(label) << endl;
    	else if (op == "<") j_file << "\tif_cmplt Label" << to_string(label) << endl;
    	else if (op == "<=") j_file << "\tif_cmple Label" << to_string(label) << endl;
    	else if (op == ">") j_file << "\tif_cmpgt Label" << to_string(label) << endl;
    	else if (op == ">=") j_file << "\tif_cmpge Label" << to_string(label) << endl;

        j_file << "\ticonst_0" << endl;
        j_file << "\tgoto Label" << to_string(label + 1) << endl;
        j_file << "Label" << to_string(label) << ":" << endl;
        j_file << "\ticonst_1" << endl;
        j_file << "Label" << to_string(label + 1) << ":" << endl;
        label += 2;
    }

    if(real_mode)
    {
    	j_file << "\tfcmpg" << endl;

    	if(op == "?=") j_file << "\tifeq Label" << to_string(label) << endl;
    	else if(op == "X=") j_file << "\tifne Label" << to_string(label) << endl;
    	else if(op == "<")  j_file << "\tiflt Label" << to_string(label) << endl;
    	else if(op == "<=") j_file << "\tifle Label" << to_string(label) << endl;
    	else if(op == ">")  j_file << "\tifgt Label" << to_string(label) << endl;
    	else if(op == ">=") j_file << "\tifge Label" << to_string(label) << endl;

    	j_file << "\ticonst_0" << endl;
    	j_file << "\tgoto Label" << to_string(label + 1) << endl;
    	j_file << "Label" << to_string(label) << ":" << endl;
    	j_file << "\ticonst_1" << endl;
    	j_file << "L0" << to_string(label + 1) << ":" << endl;
    	label += 2;
    }

    // Emit a test instruction.
    j_file << "\t" << opcode << endl;

    return value;
}

antlrcpp::Any Pass2Visitor::visitMulDivExpr(ExprParser::MulDivExprContext *ctx)
{
    auto value = visitChildren(ctx);

    TypeSpec *type1 = ctx->expr(0)->type;
    TypeSpec *type2 = ctx->expr(1)->type;

    bool integer_mode =    (type1 == Predefined::integer_type)
                        && (type2 == Predefined::integer_type);
    bool real_mode    =    (type1 == Predefined::real_type)
                        && (type2 == Predefined::real_type);

    string op = ctx->MUL_DIV()->getText();
    string opcode;

    if (op == "*")
    {
        opcode = integer_mode ? "imul"
               : real_mode    ? "fmul"
               :                "????";
    }
    else
    {
        opcode = integer_mode ? "idpv"
               : real_mode    ? "fdiv"
               :                "????";
    }

    // Emit a multiply or divide instruction.
    j_file << "\t" << opcode << endl;

    return value;
}

antlrcpp::Any Pass2Visitor::visitIdentifierExpr(ExprParser::IdentifierExprContext *ctx)
{
    string variable_name = ctx->ID()->toString();
    TypeSpec *type = ctx->type;

    string type_indicator = (type == Predefined::integer_type) ? "I"
                          : (type == Predefined::real_type)    ? "F"
                          :                                      "?";

    // Emit a field get instruction.
    j_file << "\tgetstatic\t" << program_name
		   << "/" << variable_name << " " << type_indicator << endl;

    return visitChildren(ctx);
}

antlrcpp::Any Pass2Visitor::visitIntConstExpr(ExprParser::IntConstExprContext *ctx)
{
    // Emit a load constant instruction.
    j_file << "\tldc\t" << ctx->getText() << endl;

    return visitChildren(ctx);
}

antlrcpp::Any Pass2Visitor::visitFloatingConstExpr(ExprParser::FloatingConstExprContext *ctx)
{
    // Emit a load constant instruction.
    j_file << "\tldc\t" << ctx->getText() << endl;

    return visitChildren(ctx);
}

antlrcpp::Any Pass2Visitor::visitLoop_statement(ExprParser::Loop_statementContext *ctx)
{
	//Not sure exactly how to implement this
	j_file << "L0" << ":" << endl;
    visit(ctx->statement());
    visit(ctx->Stop());
	auto value = visit(ctx->expr());
    j_file << "\tgoto L0" << endl;

    return value;
}

antlrcpp::Any Pass2Visitor::visitIf_statement(ExprParser::If_statementContext *ctx)
{
	j_file << "\tifeq L0" << endl;
    auto value = visit(ctx->expr());
    visit(ctx->statement());
    return value;
}
