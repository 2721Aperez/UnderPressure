
// Generated from Expr.g4 by ANTLR 4.7.1

#pragma once


#include "antlr4-runtime.h"
#include "ExprParser.h"



/**
 * This class defines an abstract visitor for a parse tree
 * produced by ExprParser.
 */
class  ExprVisitor : public antlr4::tree::AbstractParseTreeVisitor {
public:

  /**
   * Visit parse trees produced by ExprParser.
   */
    virtual antlrcpp::Any visitProg(ExprParser::ProgContext *context) = 0;

    virtual antlrcpp::Any visitVariable(ExprParser::VariableContext *context) = 0;

    virtual antlrcpp::Any visitTypeID(ExprParser::TypeIDContext *context) = 0;

    virtual antlrcpp::Any visitVar_dec(ExprParser::Var_decContext *context) = 0;

    virtual antlrcpp::Any visitFunction_(ExprParser::Function_Context *context) = 0;

    virtual antlrcpp::Any visitFunction_call(ExprParser::Function_callContext *context) = 0;

    virtual antlrcpp::Any visitBarren_function(ExprParser::Barren_functionContext *context) = 0;

    virtual antlrcpp::Any visitLoop_statement(ExprParser::Loop_statementContext *context) = 0;

    virtual antlrcpp::Any visitIf_statement(ExprParser::If_statementContext *context) = 0;

    virtual antlrcpp::Any visitStatement(ExprParser::StatementContext *context) = 0;

    virtual antlrcpp::Any visitAddSubExpr(ExprParser::AddSubExprContext *context) = 0;

    virtual antlrcpp::Any visitTestingExpr(ExprParser::TestingExprContext *context) = 0;

    virtual antlrcpp::Any visitNumberExpr(ExprParser::NumberExprContext *context) = 0;

    virtual antlrcpp::Any visitMulDivExpr(ExprParser::MulDivExprContext *context) = 0;

    virtual antlrcpp::Any visitParenExpr(ExprParser::ParenExprContext *context) = 0;

    virtual antlrcpp::Any visitIdentifierExpr(ExprParser::IdentifierExprContext *context) = 0;

    virtual antlrcpp::Any visitIntConstExpr(ExprParser::IntConstExprContext *context) = 0;

    virtual antlrcpp::Any visitFloatingConstExpr(ExprParser::FloatingConstExprContext *context) = 0;


};

