#ifndef PASS2VISITOR_H_
#define PASS2VISITOR_H_

#include <iostream>
#include <string>

#include "wci/intermediate/SymTabStack.h"
#include "wci/intermediate/SymTabEntry.h"
#include "wci/intermediate/TypeSpec.h"

#include "ExprBaseVisitor.h"
#include "antlr4-runtime.h"
#include "ExprVisitor.h"

using namespace wci;
using namespace wci::intermediate;

class Pass2Visitor : public ExprBaseVisitor
{
private:
	string program_name;
	ostream& j_file;

public:
	Pass2Visitor(ostream& j_file);
    virtual ~Pass2Visitor();

    antlrcpp::Any visitProg(ExprParser::ProgContext *ctx) override;
    antlrcpp::Any visitStatement(ExprParser::StatementContext *ctx) override;
    antlrcpp::Any visitAddSubExpr(ExprParser::AddSubExprContext *ctx) override;
    antlrcpp::Any visitTestingExpr(ExprParser::TestingExprContext *ctx) override;
    antlrcpp::Any visitIntConstExpr(ExprParser::IntConstExprContext *ctx) override;
    antlrcpp::Any visitMulDivExpr(ExprParser::MulDivExprContext *ctx) override;
    antlrcpp::Any visitIdentifierExpr(ExprParser::IdentifierExprContext *ctx) override;
    antlrcpp::Any visitFloatingConstExpr(ExprParser::FloatingConstExprContext *ctx) override;
};

#endif /* PASS2VISITOR_H_ */
